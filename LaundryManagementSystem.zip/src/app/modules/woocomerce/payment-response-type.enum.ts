export enum PaymentResponseType {
  INFO = 'info', SUCCESS = 'success', ERROR = 'error',
}
