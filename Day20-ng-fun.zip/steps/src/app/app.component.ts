import { Component } from '@angular/core';
/*
1)<div class="box" [class.bluebox]="showcolor" [class.roundborder]="showborder">
  The solar system is made up of the sun and everything that orbits around it, including planets, moons, asteroids, comets and meteoroids. The order of the planets in the solar system, starting nearest the sun and working outward is the following: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune and then the possible Planet Nine.
  </div>

2)<div style="border:2px solid black; background-color:lightblue">

3)<div style="border:2px solid black;"[style.background-color]="bgcolor">
  The solar system is made up of the sun and everything that orbits around it, including planets, moons, asteroids, comets and meteoroids. The order of the planets in the solar system, starting nearest the sun and working outward is the following: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune and then the possible Planet Nine.
  </div>

4) <!--<p *ngIf="showterms">{{title}}</p>-->
  */
@Component({
  selector: 'app-root',
  template: `
  <div class="box" [ngClass]="{bluebox:showcolor,roundborder:showborder}">
  The solar system is made up of the sun and everything that orbits around it, including planets, moons, asteroids, comets and meteoroids. The order of the planets in the solar system, starting nearest the sun and working outward is the following: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune and then the possible Planet Nine.
  </div>
  <br>
  <div [ngStyle]="{'background-color':showcolor ?  'pink' : 'lightblue','padding':'10px','border': '5px solid black'}">
  The solar system is made up of the sun and everything that orbits around it, including planets, moons, asteroids, comets and meteoroids. The order of the planets in the solar system, starting nearest the sun and working outward is the following: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune and then the possible Planet Nine.
  </div>
  <hr>
  Show Terms And Condition
  <input type="checkbox" (input)="showterms=!showterms">
  <fieldset *ngIf="showterms">
  <legend>Terms And Condition Apply </legend>
  <p>  
  The solar system is made up of the sun and everything that orbits around it, including planets, moons, asteroids, comets and meteoroids. The order of the planets in the solar system, starting nearest the sun and working outward is the following: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune and then the possible Planet Nine.
  </p>
  </fieldset>
  <hr>
  <ol>
  <li *ngFor="let hero of avengers">{{hero}}</li>
  </ol>
  <h3 ngNonBindable>Hello {{Mani Varshney}}</h3>
  <input type="range" #pow (input)="power=pow.value" min="5" max="10" step="1">
  <h2>Power is:{{ power }}</h2>
  <ul [ngSwitch]="power">
  <li *ngSwitchCase="6">Weak : {{power}}</li>
  <li *ngSwitchCase="7">Booster Required : {{power}}</li>
  <li *ngSwitchCase="8">Strong : {{power}}</li>
  <li *ngSwitchCase="9">Strongest : {{power}}</li>
  <li *ngSwitchCase="10">Invinsible : {{power}}</li>
  <li *ngSwitchDefault>Default Power : {{power}}</li>
  </ul>

  <hr>
 
  <ng-template [ngIf]="showterms">{{title}}</ng-template>
  <ng-template [ngIf]="showterms">
  <app-second></app-second>
  </ng-template>

  `,
  styles:[`.box{
    width:400px;
    height:150px;
    padding:10px;
    outline:1px solid black;
    text-align:center;
    }
    .bluebox{
      background-color:lightblue;
    }
    .roundborder{
      border:10px solid grey;
      border-radius:20px;
    }
  `]
 
})
export class AppComponent {
  title = 'Welcome Back';
  bgcolor='pink';
  showcolor=false;
  showborder=true;
  showterms=true;
  power='5';
  avengers=['Ironman','Antman','Captain America','Captain Marvel'];

}
