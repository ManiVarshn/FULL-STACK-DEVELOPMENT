import { NgModule } from "@angular/core";
import { IschoolComp } from "./ischool.component";
import { CustomPipe } from "./ischoolregion.pipe";
import { ParticipantsDirective } from "./participants.directive";


@NgModule({
    declarations:[IschoolComp,ParticipantsDirective,CustomPipe],
    exports:[IschoolComp,ParticipantsDirective,CustomPipe]
})
export class IschoolModule{

}