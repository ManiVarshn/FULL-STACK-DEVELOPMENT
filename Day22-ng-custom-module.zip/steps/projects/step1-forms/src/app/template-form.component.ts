import { Component } from "@angular/core";
import { NgForm } from "@angular/forms";

@Component({
    selector:'app-template-form',
    template:`
    <h2>Template Driven Form</h2>
    <form #myForm="ngForm" (submit)="formSubmitHandler(myForm,$event)" action="#"  name="myform" method="get" novalidate>
    <div class="mb-3">
    <label for="username" class="form-label">User Name</label>
    <input #uname="ngModel" name="uname" id="username" [(ngModel)]="user.name"  class="form-control" required type="text">
    <span *ngIf="uname.invalid && uname.touched" class="form-text">Please Enter Your Name</span>
    </div>

    <div class="mb-3">
    <label for="userage" class="form-label">User Age</label>
    <input #uage="ngModel" name="uage" min="18" max="80" id="userage" [(ngModel)]="user.age" class="form-control" required type="number">
    <span *ngIf="uage.invalid && uage.touched" class="form-text">Age Must Be Between 18-80 yrs</span>
    </div>

    <div class="mb-3">
    <label for="usermail" class="form-label">User E-Mail</label>
    <input #umail="ngModel" pattern=".+@.+" name="umail" id="usermail" [(ngModel)]="user.mail" class="form-control" required type="text">
    <span *ngIf="umail.invalid && umail.touched" class="form-text">Enter Your Mail</span>
    </div>
    <button type="submit" class="btn btn-primary">Register</button>
    </form>

    <ul>
    <li>User Name : {{user.name}}</li>
    <li>User Age : {{user.age}}</li>
    <li>User E-Mail : {{user.mail}}</li>
    </ul>

    <ul>
    <li *ngIf="uname.touched">User Name is Touched</li>
    <li *ngIf="uname.untouched">User Name  is Untouched</li>
    <li *ngIf="uname.pristine">User Name  is Pristine</li>
    <li *ngIf="uname.dirty">User Name  is Dirty</li>
    <li *ngIf="uname.valid">User Name  is Valid</li>
    <li *ngIf="uname.invalid">User Name is Invalid</li>
    </ul>

    <ul>
    <li *ngIf="uage.touched">User Age is Touched</li>
    <li *ngIf="uage.untouched">User Age  is Untouched</li>
    <li *ngIf="uage.pristine">User Age  is Pristine</li>
    <li *ngIf="uage.dirty">User Age  is Dirty</li>
    <li *ngIf="uage.valid">User Age  is Valid</li>
    <li *ngIf="uage.invalid">User Age is Invalid</li>
    </ul>

    <ul>
    <li *ngIf="umail.touched">User Mail is Touched</li>
    <li *ngIf="umail.untouched">User Mail  is Untouched</li>
    <li *ngIf="umail.pristine">User Mail  is Pristine</li>
    <li *ngIf="umail.dirty">User Mail  is Dirty</li>
    <li *ngIf="umail.valid">User Mail  is Valid</li>
    <li *ngIf="umail.invalid">User Mail is Invalid</li> 
    </ul>

    <ul>
    <li *ngIf="myForm.touched">User Form is Touched</li>
    <li *ngIf="myForm.untouched">User Form  is Untouched</li>
    <li *ngIf="myForm.pristine">User Form  is Pristine</li>
    <li *ngIf="myForm.dirty">User Form  is Dirty</li>
    <li *ngIf="myForm.valid">User Form  is Valid</li>
    <li *ngIf="myForm.invalid">User Form is Invalid</li> 
    </ul>
 `,
 styles:[`
 input.ng-valid.ng-touched{
     border:2px solid greenyellow


 }
 input.ng-invalid.ng-touched{
    border:2px solid crimson
 }
 `]
    
})
export class TemplateForm{
    user={
        name : '',
        age : '',
        mail : ''
    }
    formSubmitHandler(userForm:NgForm,evt:any){
        evt.preventDefault();
        //console.log(userForm);
        let info=userForm.form.value;
        if(info.uname&&info.uage&&info.umail){
            if(info.uage<18){
                alert("You are too young to join");
            }else if(info.uage>80){
                alert("You are too old to join");
            }
            else{
                //alert("You are ready to join us");
                evt.target.submit();
    
    
            }

        }
        else{
            alert("Complete Your Form");
        }
       

    }



}