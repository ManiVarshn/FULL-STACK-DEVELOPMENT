export const environment = {
  firebase: {
    projectId: 'ischool-ng-fire',
    appId: '1:682996730000:web:dfc424179a6171b0773015',
    storageBucket: 'ischool-ng-fire.appspot.com',
    apiKey: 'AIzaSyDL0e2T3IcrYM9oicQd3bfOjR3h2glxKe4',
    authDomain: 'ischool-ng-fire.firebaseapp.com',
    messagingSenderId: '682996730000',
  },
  production: true
};
