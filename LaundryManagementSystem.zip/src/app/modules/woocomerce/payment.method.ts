export enum PaymentMethod {
  CASH_ON_DELIVERY = 'cod',
  MTN_MOBILE_MONEY_CAMEROON = 'mtn_mobile_money_cameroon',
  ORANGE_MONEY_CAMEROON = 'orange_money_cameroon',
}
