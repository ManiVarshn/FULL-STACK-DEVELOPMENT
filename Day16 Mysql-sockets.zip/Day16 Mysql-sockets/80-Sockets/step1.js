const express=require("express");
const app=express();
const server=require("http").createServer(app);
const io=require("socket.io")(server);
io.on("connection",function(socket){
    console.log("A CLient Socket Is Connected");
    socket.emit("message","Hello From Socket.io");
})
app.use(express.static(__dirname));
server.listen(6060,"localhost",function(error){
    if(error){
        console.log("Error",error);
       
    }
    else{
        console.log("Server is now live on local host:6060");
    }
})