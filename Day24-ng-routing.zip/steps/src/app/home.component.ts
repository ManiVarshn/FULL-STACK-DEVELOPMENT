import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  template: `
    <h1>
      Justice League Heros
    </h1>
    <p>
    Justice League Heroes is a 2006 console video game for the Xbox and PlayStation 2 platforms. It was developed by Snowblind Studios, published by Warner Bros.
    </p>
  `,
  styles: [
  ]
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
