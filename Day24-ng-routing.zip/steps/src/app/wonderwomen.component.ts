import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wonderwomen',
  template: `
  <h1>Wonder Women Says Hi!</h1>
    <p>
    Wonder Woman is a 2017 superhero film based on the DC Comics character of the same name. Produced by Warner Bros. Pictures, Atlas Entertainment and Cruel and Unusual Films, and distributed by Warner Bros. Pictures, It is the fourth installment in the DC Extended Universe (DCEU).
    </p>
  `,
  styles: [
  ]
})
export class WonderwomenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
