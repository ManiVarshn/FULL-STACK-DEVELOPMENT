import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HerolistComponent } from './herolist.component';
import { HeroComponent } from './hero.component';
import { HeroaddComponent } from './heroadd.component';
import { HeroeditComponent } from './heroedit.component';
import { MovieComponent } from './movie.component';
import { MovielistComponent } from './movielist.component';
import { MovieaddComponent } from './movieadd.component';
import { MovieeditComponent } from './movieedit.component';
import { WelcomeComponent } from './welcome.component';
import { RouterModule } from '@angular/router';
import { HeroModule } from './hero.module';
import { MovieModule } from './movie.module';

@NgModule({
  declarations: [ AppComponent,WelcomeComponent],
  imports: [ BrowserModule,RouterModule.forRoot([
    {path:"**",component:WelcomeComponent}
]),HeroModule,MovieModule],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
