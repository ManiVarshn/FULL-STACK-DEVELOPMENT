const axios=require("axios");
const fs=require("fs");
const zlib=require("zlib");
const { get } = require("http");
/*axios("https://rollic.in/")
.then(res=> fs.writeFileSync("temp/rollic.html",res.data,"utf-8"))
.catch(error=>console.log("Error",error))*/

//When requesting huge file data
axios({
    method:"get",
    url:"https://rollic.in/",
    responseType:"stream"
})
.then(res=>{
    //res.data.pipe(fs.createWriteStream("temp/rollic2.html"));
    res.data.pipe(zlib.createGzip()).pipe(fs.createWriteStream("temp/rollic3.html.zip"));

})
.catch(error=>console.log("Error",error))


