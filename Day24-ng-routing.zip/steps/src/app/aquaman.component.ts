import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aquaman',
  template: `
    <h1>Aquaman Says Hi!</h1>
    <p>
    Aquaman is a 2018 American superhero film based on the DC Comics character of the same name. Produced by Warner Bros. Pictures, DC Entertainment and Peter Safran Productions, and distributed by Warner Bros. Pictures, it is the sixth film in the DC Extended Universe (DCEU). The film was directed by James Wan, from a screenplay by David Leslie Johnson-McGoldrick and Will Beall.
    </p>
  `,
  styles: [
  ]
})
export class AquamanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
