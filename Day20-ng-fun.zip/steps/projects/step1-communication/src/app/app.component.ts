import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
   <h1>{{title}}</h1>
   <hr>
  <!-- <app-second>{{message}}</app-second>-->
  <!-- <app-second>
   <ul>
   <li>List Item 1</li>
   <li class="x">List Item 2</li>
   <li>List Item 3</li>
   <li>List Item 4</li>
   <li>List Item 5</li>
   </ul>
   <p>
   The caves at Ajanta are excavated out of a vertical cliff above the left bank of the river Waghora in the hills of Ajanta. They are thirty in number, including the unfinished ones, of which five (caves 9, 10, 19, 26 and 29) are chaityagrihas (sanctuary) and the rest, sangharamas or viharas (monastery). The caves are connected with the river by rock-cut staircases. The excavation activity was carried out in two different phases separated by an interval of about four centuries.
   </p>
   <p class="box">
   The first phase coincides with the rule of the Satavahana dynasty from about the 2nd century BCE to the 1st century BCE, while the second phase corresponds to the Basim branch of the Vakataka dynasty with their Asmaka and Rishika feudatories in the 5th to 6th centuries CE.
   </p>
   <button>Click Me</button>
   </app-second>-->
   <app-second (compEvent)="compEventHandler($event)" [cp]="power"></app-second>
   <button (click)="power=power+1">Increase Power</button>

  `,
  styles: []
})
export class AppComponent {
  title = 'step1-communication';
  message='Hello,Mani Varshney';
  power=5;
  compEventHandler(msg:any){
    //alert(msg);
    this.title=msg;
  }
}
