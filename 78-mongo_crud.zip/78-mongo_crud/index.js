const express=require("express");
const mongoose=require("mongoose");
const app=express();
const config=require("./public/config.json");
app.use(express.static(__dirname+"/public"));
app.use(express.json());
let errorHandler=function(error){console.log("Error is",error)}
const url=config.cloudDB;
let Schema=mongoose.Schema;
let ObjectId=Schema.ObjectId;
let User=mongoose.model("User",new Schema({
    id:ObjectId,
    Username:String,
    usermail:String,
    usercity:String
}))
mongoose.connect(url)
.then(()=>{
    console.log("DB Connected");
})
.catch((error)=>{
   errorHandler(error);
})
app.get("/data",function(req,res){
    console.log("get request for data received");
   /* res.send([
            {
                name:"Ironman",
                email:"tony@gmail.com",
                city:"Gotham"
            }
        ])*/
        User.find(function(error,users){
            if(error){
                errorHandler(error);
            }
            else{
            res.json(users);
            }

        })
    });

app.post("/add",function(req,res){
        //console.log("Add User Post Request Received",req.body);
        let user=new User(req.body);
        user.save().then((function(dbres){
            res.json({'message':'user added'});

        })).catch(function(){
           errorHandler(error);
        })

    })
app.delete("/delete/:id",function(req,res){
    //console.log("delete request received with id"+req.params['id']);
    User.findByIdAndDelete({_id:req.params['id']},function(error,deleteduser){
        if(error){
           errorHandler(error);
            
        }else{
            res.json({"message": "user deleted"});

        }

    })

})
app.get("/edit/:id",function(req,res){
    User.findById(req.params['id'],function(error,edituser){
        if(error){
            errorHandler(error);
            
        }else{
            res.json(edituser);

        }
 
    })
    


})
app.post("/edit/:id",function(req,res){
    User.findById(req.params.id,function(error,updateuser){
        if(error){
            console.log(error);
            
        }else{
            updateuser.Username=req.body.Username;
            updateuser.usermail=req.body.usermail;
            updateuser.usercity=req.body.usercity;
            updateuser.save()
            .then((userupdated)=>{
                res.json({"Updatedmessage":"userupdated"})
                })
            .catch((error)=>errorHandler(error))
            }
 
    })
    


});


app.listen(config.port,config.host,function(error){
    if(error){
        errorHandler(error);
    }
    else{
        console.log(`Server is now live on ${config.host}:${config.port}`);
    }
});