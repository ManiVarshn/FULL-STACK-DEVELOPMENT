import { Component, Input } from "@angular/core";
import { ServiceComp } from "./hero.services";

@Component({
    selector:'app-head',
    template:`
    <h2>App Version:{{compVersion}}</h2>
    <ul class="nav justify-content-center">
  <li class="nav-item" *ngFor="let hero of compdata">
    <a class="nav-link" href="#">{{hero.title}}</a>
  </li>
</ul>
    `
})
export class HeadComp{

   //@Input() compdata:any;
   compdata:any;
   compVersion:any;
  /* sc:ServiceComp=new ServiceComp();
   constructor(){
     this.compdata=this.sc.getHeroData();
     this.compVersion=this.sc.getAppVersion();
   }*/
   
   constructor(private sc:ServiceComp){
    // this.compdata=this.sc.getHeroData();
       this.sc.getHeroData().subscribe((res)=>{
           this.compdata=res;
           //console.log(res);

       })
     this.compVersion=this.sc.getAppVersion();
   }
}