import { Component, OnInit, ViewChild } from '@angular/core';
import { ChildComponent } from './child.component';

@Component({
  selector: 'app-root',
  template:`
  <h1>Main Component : Power {{apppower}}</h1>
  <button (click)="increaseChildPower()">Increase Power</button>
  <button (click)="decreaseChildPower()">Decrease Power</button>
  <button (click)="showHide()">Remove Child Component</button>
  <!--<app-child *ngIf="show" [power]="apppower"></app-child>-->
 <!--<app-child *ngIf="show"></app-child>-->
 <app-child #powComp *ngIf="show"></app-child>

  `
  
})
export class AppComponent implements OnInit{
  title = 'steps';
  apppower=0;
  show=true;
  //@ViewChild(ChildComponent) cc:ChildComponent=new ChildComponent()
  @ViewChild('powComp') cc:any;
  constructor(){
    console.log("Main Component Constructor is called");
    
  }
  ngOnInit(): void {
    this.apppower=5;
    console.log("App Component Init Method Was  Called");
  }
  /*increasePower(){
    this.apppower+=1
  }
  decreasePower(){
    this.apppower-=1
  }*/
  showHide(){
    this.show=!this.show;
}
increaseChildPower(){
  this.cc.increasePower();

}
decreaseChildPower(){
  this.cc.decreasePower();

}

}
