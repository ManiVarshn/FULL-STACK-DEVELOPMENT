import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <div>
  <h2>Heroes Application</h2>
  <img #hero src="images/rajani.jpg">
  <hr>
  <button [disabled]="agree">Click Me</button>
  <button (click)="clickHandler()">Click Me</button>
  <button on-click="clickHandler()">Click Me</button>
  <button on-click="clickHandler($event)">Button 1</button>
  <button on-click="clickHandler($event)">Button 2</button>
  <button on-click="clickHandler($event)">Button 3</button>
  <button on-click="clickHandler($event)">Button 4</button>
  <br>
  <button on-click="setAgreeDisagree()">Agree/Disagree</button>
  <hr>
  <button (click)="hero.src='assets/rajani.jpg'">Rajani</button>
  <button (click)="hero.src='assets/antman.jpg'">Antman</button>
  <button (click)="hero.src='assets/hulk.jpg'">Hulk</button>
  <button (click)="hero.src='assets/iron1_tn.jpg'">IronMan</button>
  <hr>
  <h2>{{title}}</h2>
  <input [value]="title" #textIP (input)="changeTitle(textIP.value)">
  <button (click)="changeTitle(textIP.value)">Change Title</button>
  <hr>
  <input [value]="title" #textIP1 (input)="title=textIP1.value">
  <br>
  <h3>Two Way Binding</h3>
  <input [(ngModel)]="title">
  <input type="text" (keydown.space)="keypressHandler()">
  <div class="box" [class.orangebox]="agree">
  The order of the planets in the solar system, starting nearest the sun and working outward is the following: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune and then the possible Planet Nine.
 </div>
  <hr>
  <div [class]="selectedClass">
  The solar system is made up of the sun and everything that orbits around it, including planets, moons, asteroids, comets and meteoroids. The order of the planets in the solar system, starting nearest the sun and working outward is the following: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune and then the possible Planet Nine.
</div>
  </div>

 `,styles:[`.box{
   width:200px;
   outline:1px solid black
   
 }
 .orangebox{
  background-color:orange;
 }
 .borderbox{
   border:2px dashed red;
 }
 `]
 
})
export class AppComponent {
  title = 'steps-day19';
  agree=true;
  selectedClass='box';
  clickHandler(evt?:any){
    if(evt){
      alert("You Clicked On :"+evt.target.innerHTML);
    }else{
      alert("You Clicked A Button")
    }
    
  }
  setAgreeDisagree(){
    this.agree=!this.agree;
  }
  changeTitle(ntitle:string){
    this.title=ntitle;

  }
  keypressHandler(){
    console.log("Key was pressed");
  }
}
