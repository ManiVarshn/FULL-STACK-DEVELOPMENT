import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";


@Component({
    template:`
    <h2>Hero To Update :{{heroToEdit}}</h2>
    <h2>Hero To Update :{{herosNewPower}}</h2>
    `
})
export class HeroEditComp implements OnInit{
    heroToEdit:any;
    herosNewPower:any;
    constructor(private ar:ActivatedRoute){}
    ngOnInit(): void {
       this.heroToEdit= this.ar.snapshot.params['hname'];
       //this.herosNewPower=this.ar.snapshot.params['power'];
       this.ar.params.subscribe(rPower=>this.herosNewPower=rPower['power']);
    }
    
}