import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { HeroEditComp } from "projects/step3-query-optional-parameters/src/app/hero-edit.component";
import { HeroComponent } from "./hero.component";
import { HeroaddComponent } from "./heroadd.component";
import { HeroeditComponent } from "./heroedit.component";
import { HerolistComponent } from "./herolist.component";


@NgModule({
    declarations:[HeroaddComponent,HeroComponent,HeroeditComponent,HerolistComponent],
    imports:[RouterModule.forChild([
      {path:"hero",component:HeroComponent},
      {path:"heroes",component:HerolistComponent},
      {path:"addhero",component:HeroaddComponent},
      {path:"edithero",component:HeroEditComp }
    

    ])],
    exports:[HeroComponent,HerolistComponent,HeroaddComponent,HeroeditComponent]
})
export class HeroModule{

}