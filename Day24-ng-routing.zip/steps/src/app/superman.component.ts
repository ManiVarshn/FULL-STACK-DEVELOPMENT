import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-superman',
  template: `
  <h1>
  Superman Says Hi!
  </h1>
    <p>
    Superman (stylized as Superman: The Movie) is a 1978 superhero film based on the DC Comics character of the same name. An international co-production between the United Kingdom, Switzerland, Panama and the United States,[3] it was supervised by Alexander and Ilya Salkind, produced by their partner Pierre Spengler and written by Mario Puzo from a story by Puzo, and is the first installment in the Superman Film Series. Directed by Richard Donner,
    </p>
  `,
  styles: [
  ]
})
export class SupermanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
