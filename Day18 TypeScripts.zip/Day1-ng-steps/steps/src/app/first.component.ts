import { Component } from "@angular/core";

@Component({
    selector:"app-first",
    template:`
    <h1>First Component</h1>
    `
})
export class FirstComp{

}