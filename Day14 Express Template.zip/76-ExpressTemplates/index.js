const express=require("express");
const app=express();
/*let address=app.listen();
console.log("Server is now running",address.address().port);
*/
app.use(express.urlencoded({extended:true}))

//express configuration start with use /set like when we want to send file with images/css/javascript
//Most of the configuration that are use with use are middlewares

/*app.use(express.static(__dirname));
app.use("/assets",express.static(__dirname+"/images"));*/

app.locals.pretty=true;
let heros=[];
app.get("/",function(req,res){
   // res.send("Hello There From Express!!!!");
   //res.sendFile(__dirname+"/index.html");
  /* res.render("home.ejs",{
       companyname:"iSchoolConnect",
       user:false,
       heros:heros
   });/*

   /*res.render("home.pug",{
    companyname:"iSchoolConnect",
    user:false,
    heros:heros
});*/
res.render("home.jade",{
    companyname:"iSchoolConnect",
    user:false,
    heros:heros
});

})
app.post("/",function(req,res){
    //console.log(req.body.nexthero);
    heros.push(req.body.nexthero);
    //console.log(heros);
    //res.send("You Made a Post Request");
    //res.end();
    res.redirect("/");
})
app.listen(4040,"localhost",function(error){
    if(error){
        console.log("Error",error);
    }
    else{
        console.log("Server is now Live on local host:4040");
    }
})
// npm i nodemon -g
//nodemon .