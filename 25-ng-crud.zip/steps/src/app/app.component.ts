import { Component } from '@angular/core';
import { User } from './user.model';

@Component({
  selector: 'app-root',
  template: `
  <table>
  <thead>
  <tr>
  <th>Sl#</th>
  <th>User Name</th>
  <th>User City</th>
  <th>User Mail</th>

  </tr>
  </thead>
  <tbody>
  <tr>
  <td></td>
  </tr>
  </tbody>
  </table>
  
  `
})
export class AppComponent {
  title = 'steps';
  userdata:Array<User>=[
    {username : '',
      usermail : '',
      usercity:''
    }

  ]
}
