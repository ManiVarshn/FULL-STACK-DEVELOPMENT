// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  firebase: {
    projectId: 'ischool-ng-fire',
    appId: '1:682996730000:web:dfc424179a6171b0773015',
    storageBucket: 'ischool-ng-fire.appspot.com',
    apiKey: 'AIzaSyDL0e2T3IcrYM9oicQd3bfOjR3h2glxKe4',
    authDomain: 'ischool-ng-fire.firebaseapp.com',
    messagingSenderId: '682996730000',
  },
  production: false
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
