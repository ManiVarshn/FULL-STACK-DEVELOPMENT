import { Component, Input } from "@angular/core";

@Component({
    selector:'app-ischool',
    template:`
    <h2 [direct]="participant.favcol">{{ participant.title | region :participant.region}}</h2>

    `
    

})
export class IschoolComp{
    @Input() participant={
        title:'',
        region:'',
        favcol:''
    };


}