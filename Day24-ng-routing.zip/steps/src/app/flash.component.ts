import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flash',
  template: `
  <h1>
  Flash Says Hi!
  </h1>
    <p>
    The Flash is an upcoming American superhero film based on the DC Comics character of the same name. Produced by DC Films, Double Dream, and The Disco Factory, and set for distribution by Warner Bros. Pictures, it is intended to be the fourteenth film in the DC Extended Universe (DCEU). The film is directed by Andy Muschietti from a screenplay by Christina Hodson and stars Ezra Miller as Barry Allen / The Flash alongside Ron Livingston, Michael Keaton, Kiersey Clemons, Michael Shannon, Antje Traue, Sasha Calle, and Ben Affleck.
    </p>
  `,
  styles: [
  ]
})
export class FlashComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
