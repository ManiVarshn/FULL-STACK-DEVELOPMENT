import {HttpClient} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from './user.model';


@Injectable()
export class IschoolUserService{
    constructor(private http:HttpClient){}
        
    getUsers(){
            return this.http.get("http://localhost:5050/data");
}
 postUsers(user:User){
     return this.http.post("http://localhost:5050/add",user)
 }




}