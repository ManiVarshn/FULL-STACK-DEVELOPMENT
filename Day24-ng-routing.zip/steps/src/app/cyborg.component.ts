import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cyborg',
  template: `
  <h1>
  Cyborg Says Hi!
  </h1>
    <p>
    Cyborg (also known as Slinger; released in the Philippines as First Hero), is a 1989 American martial-arts cyberpunk film directed by Albert Pyun. Jean-Claude van Damme stars as Gibson Rickenbacker, a mercenary who battles a group of murderous marauders led by Fender Tremolo (Vincent Klyn) along the East coast of the United States in a post-apocalyptic future. The film is the first in Pyun's Cyborg Trilogy.
    </p>
  `,
  styles: [
  ]
})
export class CyborgComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
