import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  /*template: `
  <h1>Hello Angular</h1>
  <hr>
  <app-first></app-first>
  `*/
  template:`
  <app-header></app-header>
  <app-main></app-main>
  <app-footer></app-footer>
  `

})
export class AppComponent {
  title = 'steps';
}
