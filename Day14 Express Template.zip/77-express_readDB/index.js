const express=require("express");
const mongoose=require("mongoose");
let app=express();
let Schema=mongoose.Schema;
let ObjectId=Schema.ObjectId;
let Hero=mongoose.model("Hero",Schema({
    id:ObjectId,
    List:Array
})

);

mongoose.connect("mongodb+srv://admin:password1234@mycluster.b0c4k.mongodb.net/onlinedb?retryWrites=true&w=majority");
app.get("/",function(req,res){
    let herolist=[];
    Hero.find().then((dbres)=>{
          herolist=dbres[0].List;
        //console.log(dbres[0].list);
        res.render("home.pug",{
            templist:herolist
        })
        
    }).catch((error)=>{
        console.log(error);

    }).finally(()=>{
        console.log("Promise completed");

    })
   
   

})
app.listen(5050);
console.log("Server is now live on local host:5050");