import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HomeComponent } from './home.component';
import { SupermanComponent } from './superman.component';
import { AquamanComponent } from './aquaman.component';
import { FlashComponent } from './flash.component';
import { WonderwomenComponent } from './wonderwomen.component';
import { CyborgComponent } from './cyborg.component';
import { NotfoundComponent } from './notfound.component';
import { RouterModule } from '@angular/router';
import { BatmanComponent } from './batman.component';
import { HeroComponent } from './hero.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    SupermanComponent,
    AquamanComponent,
    FlashComponent,
    WonderwomenComponent,
    CyborgComponent,
    NotfoundComponent,
    BatmanComponent,
    HeroComponent
  ],
  imports: [
    BrowserModule,RouterModule.forRoot([
      {path:"",component:HomeComponent},
      {path:"batman",component:BatmanComponent},
      {path:"batman/:qty/:ver",component:BatmanComponent},
      {path:"aquaman",component:AquamanComponent},
      {path:"superman",component:SupermanComponent},
      {path:"flash",component:FlashComponent},
      {path:"wonderwomen",component:WonderwomenComponent},
      {path:"cyborg",component:CyborgComponent},
      {path:"ironman",redirectTo:"flash",pathMatch:"prefix"},
      {path:"**",component:NotfoundComponent},

    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }


//,{useHash:true}