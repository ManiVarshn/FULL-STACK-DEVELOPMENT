document.addEventListener("DOMContentLoaded",function(){
    document.getElementsByTagName("h1")[0].style="border:5px dashed red;text-align:center; padding:10px";

})
