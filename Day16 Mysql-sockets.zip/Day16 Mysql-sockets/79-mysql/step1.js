let mysql=require("mysql");
let connection=mysql.createConnection({
    host:"localhost",
    user:"root",
    database:"ischoolDB",
    password:""
})
connection.connect(function(error){
    if(error){
        console.log("Error",error);
    }
    else{
       /* connection.query("CREATE DATABASE ischoolDB",function(error,result){
            if(error){
                console.log("Error",error);
            }
            else{
                console.log("Result",result);
            }

        })*/

         /* let sql="CREATE TABLE participants(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(225),email VARCHAR(300))";
          connection.query(sql,function(error,result){
            if(error){
                console.log("Error",error);
            }
            else{
                console.log("Result",result);
            }
              
          })  */
         /* let sql="INSERT INTO participants(name,email)VALUES('Mani','manivarshney80@gmail.com')";
          connection.query(sql,function(error,result){
            if(error){
                console.log("Error",error);
            }
            else{
                console.log("Result",result);
            }
              
          }) */

            /*connection.query("DROP DATABASE `ischooldb`",function(error,result){
            if(error){
                console.log("Error",error);
            }
            else{
                console.log("Result",result);
            }
        })*/

       /* let heroes=[
            ["Clark","clark@Kent.com"],
            ["Bruce","bruce@waynr.com"],
            ["Peter","peter@parker.com"]
        ];
        let sql="INSERT INTO participants(name,email)VALUES ?";*/
        /*connection.query(sql,[heroes],function(error,result){
            if(error){
                console.log("Error",error);
            }
            else{
                console.log("Result",result);
            }

        })*/
        /*let sql="INSERT INTO participants(name,email)VALUES('kit','kit@walker.com'),('Bruce','bruce@wenner.com'),('natasha','nasha@walker.com')";*/
        //let sql="SELECT * FROM participants";
        let sql="SELECT name from participants WHERE id=1"
       connection.query(sql,function(error,result){
            if(error){
                console.log("Error",error);
            }
            else{
                console.log("Result",result);
               // result.forEach(recordSet => {
                    //console.log(recordSet);
                    //console.log(recordSet.name);

                    
                //});
            }

        });
        
    }
});