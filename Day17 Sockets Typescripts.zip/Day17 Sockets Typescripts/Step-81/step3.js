const express=require("express");
const app=express();
const http=require("http").createServer(app);
const io=require("socket.io")(http);
app.use(express.static(__dirname));
app.use(express.static(__dirname+"/public"));
io.on("connection",function(socket){
   console.log("Socket Connection Success");
    socket.emit("ServerMessage","Client Connected Step 3");

    socket.on("clientMessage",function(req){
       io.emit("ServerMessage",{
           username:req.username,
           message:req.message

       });
    })
    socket.on("disconnect",function(){
        console.log("Socket Disconnected");
     })
});


http.listen(2020);
console.log("Server is now live on port number:2020");