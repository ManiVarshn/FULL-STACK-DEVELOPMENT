"use strict";
alert("Hi Everyone");
