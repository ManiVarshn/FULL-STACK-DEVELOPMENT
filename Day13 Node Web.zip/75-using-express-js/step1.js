const { application } = require("express");
const express=require("express");
const app=express();
app.get("/",function(req,res){
    /*res.write("Hello There From Http Module");
    res.end();*/
    //res.send("Hello From Express Module");
   // res.send("<h1>Hello From Express Module</h1>");

res.sendFile(__dirname+"/index.html");
})
app.listen(2020,"localhost");
console.log("Server is now live");
