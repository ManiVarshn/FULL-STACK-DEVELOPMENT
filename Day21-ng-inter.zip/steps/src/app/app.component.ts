import { Component } from '@angular/core';
import { ServiceComp } from './hero.services';

@Component({
  selector: 'app-root',
  template: `
 <!--<div class="container">
  <h1>Angular Event Handling</h1>
  <br>
<ol>
<li *ngFor="let hero of herodata">{{hero.title}}</li>
</ol>

<table class="table table-striped table-bordered">
<thead>
<tr><th>Sl</th>
<th>Title</th>
<th>Full Name</th>
<th>Poster</th>
<th>City</th>
<th>Ticket Price</th>
<th>Release Date</th>
<th>Movies List</th>
</tr>
</thead>
<tbody>
<tr *ngFor="let hero of herodata">
<td>{{hero.sl}}</td>
<td>{{hero.title | uppercase}}</td>
<td>{{hero.firstname+" "+hero.lastname}}</td>
<td>
<img class="img-thumbnail" [src]="hero.poster" [alt]="hero.title" width="50px">
</td>
<td>{{hero.city}}</td>
<td>{{hero.ticketprice | currency:'INR':'symbol' : '3.2-4'}}</td>
<td>{{hero.releasedate |date :'dd-MMMM-yyyy'}}</td>
<td>
<div *ngIf="hero.movieslist.length >0" class="card">
  <ul class="list-group list-group-flush">
    <li *ngFor="let movies of hero.movieslist" class="list-group-item">
    <img [src]="movies.poster"width="30"/>
    {{movies.title}}</li>
</ul>
</div>

</td>
</table>
</div>-->





<div class="container">
  <h1>Angular Event Handling</h1>
  <!--<app-head [compdata]="appdata"></app-head>-->
  <app-head></app-head>
<hr>
<!--<app-grid [compdata]="appdata"></app-grid>-->
<app-grid></app-grid>
<hr>
<!--<ischool>
<p>Some Content</p>
</ischool>
<ischool>
<p>Some Content</p>
</ischool>
<ischool>
<p>Some Content</p>
</ischool>-->

<!--<p class="ischool">Some Content</p>
<p class="ischool">Some Content</p>
<p class="ischool">Some Content</p>-->

<p ischool='{"txtcol":"red","bgcol":"grey","tagtype":"button"}'>Some Content</p>
<p ischool="yellow">Some Content</p>
<p ischool="green">Some Content</p>

</div>
  `
})
export class AppComponent {
  appdata:any;
 /* sc:ServiceComp=new ServiceComp();
  constructor(){
    this.appdata=this.sc.getHeroData();
  }*/

 
}
