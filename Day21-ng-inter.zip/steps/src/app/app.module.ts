import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule} from '@angular/common/http';

import { AppComponent } from './app.component';
import { GridComp } from './grid.component';
import { HeadComp } from './header.component';
import { ServiceComp } from './hero.services';
import { GeneratePipe } from './gen.pipe';
import { IschoolDirective } from './ischool.directive';

@NgModule({
  declarations: [AppComponent,GridComp,HeadComp,GeneratePipe,IschoolDirective],
  imports: [BrowserModule, HttpClientModule],
  providers: [ServiceComp],
  bootstrap: [AppComponent]
})
export class AppModule { }
