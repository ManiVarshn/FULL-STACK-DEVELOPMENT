import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HeroesService } from './heroes.service';

@Component({
  selector: 'app-detail',
  template: `
  <a [routerLink]="['']" queryParamsHandling="preserve">Back To Master Page</a>
  <h2>{{selectedHero.name}}:{{selectedHero.powerstats.power}} </h2>
  <img [src]="'assets/'+selectedHero.image.url" [alt]="selectedHero.name" width="150">
    <p>
     {{selectedHero|json}}
    </p>
    <a [routerLink]="['edit',selectedHero.powerstats.power,selectedHero.name]">Edit {{selectedHero.name}}</a>
    <br>
    <input min="0" max="100" type="range" [(ngModel)]="selectedHero.powerstats.power">
    <a [routerLink]="['edit',selectedHero.powerstats.power,selectedHero.name]">set power of {{selectedHero.name}}</a>
    <hr>
     <h3>Filter Heroes By:{{masterFilterOn}}</h3>
     <h3>Username is : {{username}}</h3>
     <h3>City is : {{city}}</h3>
    <router-outlet></router-outlet>
  `,
  styles: [
  ]
})
export class DetailComponent implements OnInit {
    selectedHero:any;
    masterFilterOn:any;
    username='guest';
    city='default';
  constructor(private hs:HeroesService,private ar:ActivatedRoute) { }

  ngOnInit(): void {
    this.selectedHero=this.hs.getSelectedHero(this.ar.snapshot.queryParams['hid']);
    this.masterFilterOn=this.hs.getSelectedHero(this.ar.snapshot.queryParams['filterOn']);
    this.username=this.ar.snapshot.params['username']; 
    this.city=this.ar.snapshot.params['city'];
  }

}
