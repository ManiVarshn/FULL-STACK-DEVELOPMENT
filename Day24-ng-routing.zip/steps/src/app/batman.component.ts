import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-superman',
  template: `
  <h1>
  Batman Says Hi!
  </h1>
  <h2>Quantity : {{quantity || '0'}}</h2>
  <h2>Version : {{version||'0'}}</h2>
    <p>
    The Batman is a 2022 American superhero film based on the DC Comics character Batman. Produced by DC Films, 6th & Idaho, and Dylan Clark Productions, and distributed by Warner Bros. Pictures, it is a reboot of the Batman film franchise. The film was directed by Matt Reeves, who wrote the screenplay with Peter Craig. It stars Robert Pattinson as Bruce Wayne / Batman alongside Zoë Kravitz, Paul Dano, Jeffrey Wright, John Turturro, Peter Sarsgaard, Andy Serkis, and Colin Farrell. 
    </p>
  `,
  styles: [
  ]
})
export class BatmanComponent implements OnInit {
    quantity:any;
    version:any;

  constructor(private ar:ActivatedRoute) { }

  ngOnInit(): void {
      this.quantity=this.ar.snapshot.params['qty']
      this.version=this.ar.snapshot.params['ver']
  }

}
