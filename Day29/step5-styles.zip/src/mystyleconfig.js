export let extStyle = { 
    backgroundColor : 'darkgrey', 
    width : '400px',
    padding : '10px', 
    margin : "10px",
    fontFamily : 'Arial', 
    color : "papayawhip", 
    textAlign:"justify" 
}