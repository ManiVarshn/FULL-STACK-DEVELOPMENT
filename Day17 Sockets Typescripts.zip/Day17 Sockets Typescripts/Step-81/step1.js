const express=require("express");
const app=express();
const http=require("http").createServer(app);
const io=require("socket.io")(http);
app.use(express.static(__dirname));
app.use(express.static(__dirname+"/public"));
//let clientList=1;
io.on("connection",function(socket){
   console.log("Socket Connection Success");
    socket.emit("ServerMessage","Client Connected ");
    //clientList++;
    socket.on("disconnect",function(){
        console.log("Socket Disconnected");
     })
});


http.listen(2020);
console.log("Server is now live on port number:2020");