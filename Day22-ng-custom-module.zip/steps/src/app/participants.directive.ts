import { Directive, ElementRef, Input } from "@angular/core";


@Directive({
    selector:'[direct]'
})
export class ParticipantsDirective{
    @Input() direct:any;
    constructor(private elm:ElementRef){}
    ngOnInit(){
        if(this.direct=="#000000"){
            console.log("found"+this.direct);
            this.elm.nativeElement.style.backgroundColor=this.direct;
            this.elm.nativeElement.style.color='white';
            this.elm.nativeElement.style.padding='10px';
            this.elm.nativeElement.style.padding='0px';
            this.elm.nativeElement.style.marginBottom='5px';
        }
        else{
            this.elm.nativeElement.style.backgroundColor=this.direct;
            this.elm.nativeElement.style.padding='10px';
            this.elm.nativeElement.style.padding='10px';
            this.elm.nativeElement.style.padding='0px';
            this.elm.nativeElement.style.marginBottom='5px';

        }
    }




}