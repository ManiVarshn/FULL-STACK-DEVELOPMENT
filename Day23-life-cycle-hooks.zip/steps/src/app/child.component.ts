import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, DoCheck, Input, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-child',
  template:`
  <h1>Child Component</h1>
  <h2>Power : {{power}}</h2>
  `
  
})
export class ChildComponent implements OnInit,OnChanges,DoCheck,AfterContentInit,AfterContentChecked,AfterViewInit,AfterViewChecked,OnDestroy{
  title = 'steps';
  //@Input() power=0;
  power=0;
 
  constructor(){
      console.log("Child Component Constructor Was Called");
  }
  increasePower(){
    this.power+=1
  }
  decreasePower(){
    this.power-=1
  }
  ngOnInit(): void {
      console.log("Child Component Init Function Was Called");
  }
  ngOnChanges(pow:any): void {
      if(pow.power. currentValue>=10){
          this.power=0;
      }
      console.log("Child Component OnChanges Function Was Called")

      
  }
 
  ngDoCheck(): void {
      console.log("Child Component Do CHeck Is Called");
      
  }
  ngAfterContentInit(): void {
    console.log("Child Component After Content Init Is Called");
      
  }
  ngAfterContentChecked(): void {
    console.log("Child Component After Content CHecked Is Called");
  }
  ngAfterViewInit(): void {
    console.log("Child Component After View Init Is Called");
      
  }
  ngAfterViewChecked(): void {
    console.log("Child Component After View Checked  Is Called");
      
  }
  ngOnDestroy(): void {
    console.log("Child Component Destroy Is Called");
      
  }
  


}
