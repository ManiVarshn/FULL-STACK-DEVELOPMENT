let Addpower=function(config:any){
    return function(targetclass:any){
        return class{
            title=new targetclass().title;
            power=config.power;
            city=config.city;
        }
    }
}
@Addpower({
    power:6,
    city:"Gotham"
})class commonman{
    title="Bruce Wayne"
}
let batman=new commonman();
console.log(batman);