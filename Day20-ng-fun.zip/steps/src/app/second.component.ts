import { Component } from "@angular/core";

@Component({
    selector:'app-second',
    template:`
    <h1>Hello There </h1>
    <hr>
    <ng-content></ng-content>
    `
})
export class SecondTemplate{

}